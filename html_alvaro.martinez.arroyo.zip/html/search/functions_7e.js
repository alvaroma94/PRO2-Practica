var searchData=
[
  ['_7ebiblioteca',['~Biblioteca',['../class_biblioteca.html#ae3f55e8952ed4bdddb82ece48c52f6c0',1,'Biblioteca']]],
  ['_7eesquema',['~Esquema',['../class_esquema.html#a35493f2aa427f0cea80f7ece50d22f6e',1,'Esquema']]],
  ['_7erevista',['~Revista',['../class_revista.html#ab705e2fe5ec9a46daf3a69835772a3c6',1,'Revista']]]
];
