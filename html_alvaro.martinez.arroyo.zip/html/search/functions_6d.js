var searchData=
[
  ['main',['main',['../pro2_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'pro2.cpp']]],
  ['mod_5fc1',['mod_c1',['../class_revista.html#a526d3f522dfdd299ddd7ef3d317c3101',1,'Revista']]],
  ['mod_5fc2',['mod_c2',['../class_revista.html#af48636e38adc7248ae7a2028e51bc9f2',1,'Revista']]]
];
