var searchData=
[
  ['biblioteca_2ecpp',['Biblioteca.cpp',['../_biblioteca_8cpp.html',1,'']]],
  ['biblioteca_2ehpp',['Biblioteca.hpp',['../_biblioteca_8hpp.html',1,'']]]
];
