var searchData=
[
  ['eliminar_5frevista',['eliminar_revista',['../class_biblioteca.html#a01cd1e76edd489bdfc49f112129860ba',1,'Biblioteca']]],
  ['escribir_5frevista',['escribir_revista',['../class_revista.html#a22abd6f25251e007e5e08bfd11d060a0',1,'Revista']]],
  ['esquema',['Esquema',['../class_esquema.html',1,'Esquema'],['../class_esquema.html#af1460486d823ed42510655affd487fa1',1,'Esquema::Esquema()']]],
  ['esquema_2ecpp',['Esquema.cpp',['../_esquema_8cpp.html',1,'']]],
  ['esquema_2ehpp',['Esquema.hpp',['../_esquema_8hpp.html',1,'']]]
];
