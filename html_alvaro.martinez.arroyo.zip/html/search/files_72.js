var searchData=
[
  ['revista_2ecpp',['Revista.cpp',['../_revista_8cpp.html',1,'']]],
  ['revista_2ehpp',['Revista.hpp',['../_revista_8hpp.html',1,'']]]
];
