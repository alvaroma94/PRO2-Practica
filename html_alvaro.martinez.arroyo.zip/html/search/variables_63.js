var searchData=
[
  ['c1',['c1',['../class_revista.html#ae4142bc39207ffc39691c5a88d0c9162',1,'Revista']]],
  ['c2',['c2',['../class_revista.html#a55e1411b360476402d364c0b956d7fc6',1,'Revista']]]
];
