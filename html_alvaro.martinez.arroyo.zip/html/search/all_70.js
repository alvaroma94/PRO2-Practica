var searchData=
[
  ['palabrasclave',['palabrasclave',['../class_revista.html#ad149f8b2c389babf03d75a1347b1c56a',1,'Revista']]],
  ['pro2_2ecpp',['pro2.cpp',['../pro2_8cpp.html',1,'']]]
];
