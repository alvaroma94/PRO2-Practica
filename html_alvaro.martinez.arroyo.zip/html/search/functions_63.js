var searchData=
[
  ['calcular_5fc1',['calcular_c1',['../class_esquema.html#a2a237e94381f752b6f5cb582987b0570',1,'Esquema']]],
  ['calcular_5fc2',['calcular_c2',['../class_esquema.html#a50c270ca5ba9dbd129fe047fb7a18363',1,'Esquema']]],
  ['cons_5fc1',['cons_c1',['../class_revista.html#ae069d5a6c3e1c7996388505b4fde5a53',1,'Revista']]],
  ['cons_5fc2',['cons_c2',['../class_revista.html#a56072f31d4ee209c961cf3495a6a0687',1,'Revista']]],
  ['cons_5fnombre',['cons_nombre',['../class_revista.html#a2739f78a2d67490287421da71b5ea2f6',1,'Revista']]],
  ['cons_5fnumeropalabrasclave',['cons_numeropalabrasclave',['../class_revista.html#a69d99a64d3ef987db733b4f492c53db8',1,'Revista']]],
  ['cons_5fpalabrasclave',['cons_palabrasclave',['../class_revista.html#aad8d277011c68f7acdeac6f3d47d28cb',1,'Revista']]],
  ['consultar_5frevista',['consultar_revista',['../class_biblioteca.html#a44e062939e33e5da4743da5197b971f7',1,'Biblioteca']]]
];
