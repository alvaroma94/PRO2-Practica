var searchData=
[
  ['palabrasclave',['palabrasclave',['../class_revista.html#ad149f8b2c389babf03d75a1347b1c56a',1,'Revista']]]
];
