var searchData=
[
  ['a',['a',['../class_esquema.html#aee89f1d564d1951112b2f10a47f943aa',1,'Esquema']]],
  ['a1',['A1',['../struct_biblioteca_1_1_a1.html',1,'Biblioteca']]],
  ['alta_5frevista',['alta_revista',['../class_biblioteca.html#a3a699f219da645b8c461d1d07dbf6c76',1,'Biblioteca']]],
  ['auxcalcular_5fc1',['auxcalcular_c1',['../class_esquema.html#a77210c8349dc7dccbaa8224c2da4e50e',1,'Esquema']]],
  ['auxcalcular_5fc2',['auxcalcular_c2',['../class_esquema.html#a1e863b6bd93430abe836d339bd7bcba7',1,'Esquema']]]
];
