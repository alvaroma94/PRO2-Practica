var searchData=
[
  ['biblioteca',['biblioteca',['../class_biblioteca.html#a83688a3fd707fd8671178e82d7c53f6e',1,'Biblioteca']]]
];
