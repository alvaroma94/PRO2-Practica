var searchData=
[
  ['fusionar_5flistas',['fusionar_listas',['../class_esquema.html#abf74b66701d3ab70316d8740cdd0bc25',1,'Esquema']]],
  ['fusionar_5frevista',['fusionar_revista',['../class_revista.html#a039821163b9175aa556d94b6d7fd6f63',1,'Revista']]]
];
