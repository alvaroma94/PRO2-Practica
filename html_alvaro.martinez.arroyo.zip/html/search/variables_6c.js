var searchData=
[
  ['l1',['L1',['../struct_biblioteca_1_1_a1.html#a5aa560f4da33b9157b1b69c974de59c2',1,'Biblioteca::A1']]],
  ['l2',['L2',['../struct_biblioteca_1_1_a1.html#a8463b0647409ec910cfdbf7fdaaa86b2',1,'Biblioteca::A1']]]
];
