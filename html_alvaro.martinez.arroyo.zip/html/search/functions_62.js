var searchData=
[
  ['baja_5frevista',['baja_revista',['../class_biblioteca.html#a3a5acce11e50bd1c262dabe293567b48',1,'Biblioteca']]],
  ['biblioteca',['Biblioteca',['../class_biblioteca.html#a021f69adcc57a5d04e6e12532a684e2b',1,'Biblioteca']]]
];
