var searchData=
[
  ['nombre',['nombre',['../class_revista.html#a8f33fc429436702dc5bdd6abff4ec9ac',1,'Revista']]]
];
