var searchData=
[
  ['l1',['L1',['../struct_biblioteca_1_1_a1.html#a5aa560f4da33b9157b1b69c974de59c2',1,'Biblioteca::A1']]],
  ['l2',['L2',['../struct_biblioteca_1_1_a1.html#a8463b0647409ec910cfdbf7fdaaa86b2',1,'Biblioteca::A1']]],
  ['leer_5fesquema',['leer_esquema',['../class_esquema.html#ad6c7e82a2322bd19412efa51d2005ede',1,'Esquema']]],
  ['leer_5fesquema2',['leer_esquema2',['../class_esquema.html#acdc1f43dae72e916d6baf7f53f973a21',1,'Esquema']]],
  ['leer_5frevista',['leer_revista',['../class_revista.html#a61178cb7b236db9a3354d5d00df1b31b',1,'Revista']]],
  ['listar_5frevistas',['listar_revistas',['../class_biblioteca.html#a1560e54ae8e81b7c0190b636278af7b5',1,'Biblioteca']]]
];
